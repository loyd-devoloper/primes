<x-mail::message>


You have successfully submitted your application for the {{ $position }} position in the {{ $department }}

Here is your application code:


<strong><p style="color:black;font-size: 2rem">32131 3213123213</p></strong>

The Result of initial evaluation shall be sent to your respective email address for your information.

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
