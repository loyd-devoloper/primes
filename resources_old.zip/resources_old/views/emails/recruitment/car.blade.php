<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        *{
            color: black;
            font-weight: 400;
        }

        .container{
           max-width: 60rem;
        }
    </style>
</head>
<body>



<div class="container">
    <p>Dear Candidates:</p>


    <p >Please see attached file, re subject matter, for your information and reference.</p>

    <br>
    <p  style="font-weight: 600; font-style: italic">This is an automatically generated email. Please acknowledge receipt of this email with attachment at : hrmpsb.calabarzon@deped.gov.ph.</p>
    <br>
    <p>Thank you.</p>
    <div>
        <p><span  style="font-weight: bold">HRMPSB Secretariat</span> <br><span  style="font-weight: bold"> Personnel Section</span> <br><span style="font-weight: bold">DepEd Region IV-A CALABARZON</span> <br>Gate 2, Karangalan Village <br>Cainta, Rizal</p>

    </div>
   </div>
</body>
</html>

