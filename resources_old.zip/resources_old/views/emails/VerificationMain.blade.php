<x-mail::message>
# Verification Code

Code: {{ $code }}



Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
