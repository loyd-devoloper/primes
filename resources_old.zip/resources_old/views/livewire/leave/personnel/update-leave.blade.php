<div>

    {{ $this->table }}
</div>
