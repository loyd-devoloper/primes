<div >


            <div wire:loading wire:target='_finishUpload'>
                <div class="fixed top-0 min-h-[100svh] bg-black/60  left-0 w-full  flex justify-center items-center z-[999]" >

                    @include('components.loading')
                </div>
            </div>



    {{ $this->table }}
</div>
