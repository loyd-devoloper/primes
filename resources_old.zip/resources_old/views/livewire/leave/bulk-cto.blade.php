<div>
    {{ $this->table }}

</div>
