<div>
        {{$this->table}}
</div>
