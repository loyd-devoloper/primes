<x-assets.admin_layout target="callMountedTableAction">
    <x-slot name="modal">
        <div x-cloak class="z-50">
            {{--            <x-filament-actions::modals class="z-50"/>--}}
        </div>
    </x-slot>
    <div>


        <x-filament::section>
            <x-slot name="heading">
                User details
            </x-slot>
            @livewire(\App\Livewire\CAD\CadChart::class)
            {{-- Content --}}
            <main class="text-sm">
                <div class="grid gap-10">
                    <div class="flex justify-between">
                        <article>
                            <h1>Gender</h1>
                            <div class="pl-5">
                                <li>Male</li>
                                <li>Female</li>
                            </div>
                        </article>
                        <div id="chart" wire:ignore></div>
                    </div>
                    <div class="flex justify-between">
                        <article>
                            <h1>Civil Status</h1>
                            <div class="pl-5">
                                <li>Single</li>
                                <li>Widdowed</li>
                                <li>Married</li>
                                <li>Seperated</li>
                                <li>Solo Patent</li>
                            </div>
                        </article>
                        <div id="civilStatuschart" wire:ignore></div>
                    </div>

                    <div class="flex justify-between">
                        <article>
                            <h1>Status appointment</h1>
                            <div class="pl-5">
                                <li>Permanent</li>
                                <li>Contractual</li>
                                <li>Job Order</li>
                                <li>Casual</li>
                                <li>Contract of service</li>
                                <li>Temporary</li>
                            </div>
                        </article>
                        <div id="statusAppointmentStatuschart" wire:ignore></div>
                    </div>
                    <div class="flex justify-between">
                        <article>
                            <h1>Age</h1>
                            <div class="pl-5">
                                <li>Permanent</li>
                                <li>Contractual</li>
                                <li>Job Order</li>
                                <li>Casual</li>
                                <li>Contract of service</li>
                                <li>Temporary</li>
                            </div>
                        </article>
                        <div id="ageStatuschart" wire:ignore></div>
                    </div>
                </div>
            </main>
        </x-filament::section>


    </div>

</x-assets.admin_layout>


@script
<script>
    Alpine.data('skillDisplay', () => ({
        aside: true,
        option(value, labels,type = 1) {
            let newLabel = [];
            newLabel = labels;
            if(type == 1)
            {


                var data = [];
                var label = [];
                Object.keys(value).map(function (key){

                    // data.push(value[key]);
                    // label.push(key);
                    newLabel[key] = value[key];
                });
                Object.keys(newLabel).map(function (key){
                    data.push(newLabel[key]);
                    label.push(key);
                })
            }else if(type == 2)
            {
                var data = [];
                var label = [];
                var i = 0;

                var result = Object.keys(value).map((key) => value[key]);




                Object.keys(newLabel).map(function (keylabel){
                        const main = keylabel.split('to');
                        const first = parseInt(main[0]);
                        const second = parseInt(main[1]);
                        console.log(result)
                    const grouped = result.reduce((acc, num) => {


                        // If the number is not already a key in the accumulator, initialize it
                        if (!acc[num]) {
                            acc[num] = 0;
                        }
                        // Increment the count for this number
                        acc[num]++;
                        return acc;
                    }, {});
                    // const filter = result.filter((val) =>{
                    //
                    //     return val > first && val < second ? val : 0;
                    // })
                    // data.push(filter[0] == undefined ? 0 : filter[0])
                    label.push(keylabel);

                })

                // console.log(data)

            }
            // console.log(result)
            const options = {
                series: [{
                    name: 'total',
                    data: data,
                }],
                chart: {
                    // height: 200,
                    width: 500,
                    type: 'bar',
                },
                plotOptions: {
                    bar: {
                        borderRadius: 10,
                        dataLabels: {
                            position: 'center', // top, center, bottom
                        },
                    }
                },
                // dataLabels: {
                //     enabled: true,
                //     formatter: function(val) {
                //         return val;
                //     },
                //     offsetY: -20,
                //     style: {
                //         fontSize: '12px',
                //         colors: ["#304758"]
                //     }
                // },

                xaxis: {
                    categories: label,
                    position: 'bottom',
                    axisBorder: {
                        show: false
                    },
                    axisTicks: {
                        show: false
                    },
                    crosshairs: {
                        fill: {
                            type: 'gradient',
                            gradient: {
                                colorFrom: '#D8E3F0',
                                colorTo: '#BED1E6',
                                stops: [0, 100],
                                opacityFrom: 0.4,
                                opacityTo: 0.5,
                            }
                        }
                    },
                    tooltip: {
                        enabled: true,
                    }
                },
                yaxis: {
                    axisBorder: {
                        show: false
                    },
                    axisTicks: {
                        show: false,
                    },
                    labels: {
                        show: false,
                        formatter: function (val) {
                            return val;
                        }
                    }

                },

            };

            return options;
        },
        init() {


            setTimeout(() => {
                const sexLabel = {Male: 0, Female: 0};
                var chart = new ApexCharts(document.querySelector("#chart"), this.option( @js($genderCounts), sexLabel));
                chart.render();

                const civilStatuschartLabel = {Single: 0, Widowed: 0, Married: 0, Seperated:0, 'Solo Parent': 0};
                var civilStatuschart = new ApexCharts(document.querySelector("#civilStatuschart"), this.option(@js($civil_status), civilStatuschartLabel));
                civilStatuschart.render();

                const appointmentchartLabel = {Permanent: 0, Contractual: 0, 'Job Order': 0, Casual: 0,'Contract of Service': 0, 'Temporary' : 0};
                var statusAppointmentStatuschart = new ApexCharts(document.querySelector("#statusAppointmentStatuschart"), this.option(@js($status_appointment), appointmentchartLabel));
                statusAppointmentStatuschart.render();



                const agechartLabel = {'20 to 30 years old': 0, '30 to 40 years old': 0, '40 to 50 years old': 0, '50 to 60 years old': 0,'60 to 70 years old': 0, '70 to 80 years old' : 0};
                var ageStatuschart = new ApexCharts(document.querySelector("#ageStatuschart"), this.option(@js($allBirthData), agechartLabel,2));
                ageStatuschart.render();
            }, 500);

        }
    }));
</script>
@endscript
