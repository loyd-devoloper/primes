<x-filament-widgets::widget>
    <x-filament::section>

    </x-filament::section>
</x-filament-widgets::widget>
{{-- @script
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var events = @json($this->getEvents());

        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            events: events,
        });

        calendar.render();
    });
</script>
@endscript --}}
