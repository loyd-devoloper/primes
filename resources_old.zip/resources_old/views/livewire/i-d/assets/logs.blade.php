<img src="{{ asset("storage/$log->photo") }}" alt="">
