<div>

    <section class="flex justify-center items-center min-h-[100svh]">
  <object data="https://192.168.1.31/personnel/public/uploaded_certificate/No_files_Upload.pdf" type="application/pdf" width="100%" height="500px">
        <p>Unable to display PDF file. <a href="https://192.168.1.31/personnel/public/uploaded_certificate/No_files_Upload.pdf">Download</a> instead.</p>
      </object>

    </section>
</div>
