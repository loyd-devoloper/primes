<div class="relative mx-auto my-20 w-fit">
    <img src="{{ asset('assets/r4a.png') }}"
    class="min-w-[6rem] max-w-[6rem] min-h-[6rem] max-h-[6rem]  rounded-full  "
    alt="" >
    <svg viewBox="0 0 250 250"  class="fill-white animate-spin-slow absolute -top-4 -left-4   min-w-[8rem] max-w-[8rem] min-h-[8rem] max-h-[8rem]">
        <path id="curve" class="fill-transparent" d="M 25 125 A 100 100 0 1 1 25 127"></path>
        <text class=" font-medium text-3xl">
            <textPath href="#curve" >
                DEPED CALABARZON
            </textPath>
        </text>
    </svg>


</div>
