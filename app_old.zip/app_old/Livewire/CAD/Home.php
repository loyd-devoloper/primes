<?php

namespace App\Livewire\CAD;

use App\Models\UserInfo;
use App\Models\WorkExperience;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;
use Livewire\Component;
use Filament\Forms\Components\DatePicker;
use Filament\Pages\Concerns\ExposesTableToWidgets;
use Filament\Pages\Dashboard\Actions\FilterAction;
use Livewire\Attributes\Title;

class Home extends Component
{
    use ExposesTableToWidgets;

    public $x = 7889 ;
    public function generateCad()
    {
        $this->x = rand(0,9999);

    }
    #[Title('GAD')]
    public function render()
    {
        $genderCounts = UserInfo::select('sex')
            ->get()
            ->groupBy('sex')
            ->map->count();

        $civil_status = UserInfo::query()->select('civil_status','id_number')
            ->get()
            ->groupBy('civil_status')->map->count();

        $status_appointment = WorkExperience::select('status_appointment')
            ->where('to','PRESENT')
            ->get()
            ->groupBy('status_appointment')
            ->map->count();

        $age = UserInfo::select('birth_date')->get();
        $allBirthData = $age->map(function ($date) {
            if(!!$date->birth_date)
            {
                return Carbon::parse(Crypt::decryptString($date->birth_date))->diffInYears(Carbon::now());
            }
        });



        return view('livewire.c-a-d.home',compact('genderCounts','civil_status','status_appointment','allBirthData'));
    }
}
