<?php

namespace App\Livewire\Leave;

use App\Models\User;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\ViewField;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\Crypt;
use Livewire\Component;
use Filament\Actions\Action;
use Filament\Actions\Concerns\InteractsWithActions;
use Filament\Actions\Contracts\HasActions;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class BulkDtrView extends Component  implements HasForms, HasActions
{
    use InteractsWithActions;
    use InteractsWithForms;
    public $bulk_dtr_id = '';
    public function mount($bulk_dtr_id)
    {
        $this->bulk_dtr_id = $bulk_dtr_id;

    }
    public function assignUserAction(): Action
    {
        return Action::make('assignUser')
            ->record(\App\Models\Leave\LeaveBulkDtr::query()->where('id', $this->bulk_dtr_id)->first())
            ->form([
                Select::make('employee')
                    ->label('Employee')
                    ->options(User::all()->pluck('name', 'id_number'))
                    ->searchable()
                    ->native(false)
            ])
            ->action(function ($data,$arguments,$record){

                $key = $arguments[0][1];

                $keyFormatted = explode('--',$arguments[0][0]['key'])[1];

                $user = \App\Models\User::query()
                    ->select(['id_number','dtr_key','name'])
                    ->where('id_number',$data['employee'])
                    ->first();

                \App\Models\User::query()
                    ->select(['id_number','dtr_key','name'])
                    ->where('id_number',$data['employee'])->update([
                        'dtr_key'=> $keyFormatted,
                    ]);
//                                        $check = \App\Models\Leave\LeaveBulkDtr::query()->where("dtr->$key",'!=',null)->first();
                $dtr = json_decode($record->dtr,true);

                $userData  = $dtr;

                $userData[$key]['id_number'] = $data['employee'];
                $userData[$key]['name'] = $user->name;;


                $record->update(['dtr'=>json_encode($userData)]);

                Notification::make()
                    ->title('Updated successfully')
                    ->success()
                    ->send();


            });
    }

    public function syncAction(): Action
    {
        return Action::make('sync')
            ->record(\App\Models\Leave\LeaveBulkDtr::query()->where('id', $this->bulk_dtr_id)->first())
            ->label('sync')
            ->disabled(fn($arguments) =>$arguments[0][0]['sync'] )
            ->action(function ($arguments,$record){

                $key = $arguments[0][1];
                $data = $arguments[0][0];
                $data['sync'] = true;

                $dtr = json_decode($record->dtr,true);
                $userData  = $dtr;
                $userData[$key]['sync'] = true;

                $record->update(['dtr'=>json_encode($userData)]);
                \App\Models\Leave\LeaveMyDtr::query()->updateOrCreate([
                    'key' => $key,
                    'id_number' => $data['id_number'],
                    'bulk_dtr_id' =>  $record->id,
                ],[
                    'key' => $key,
                    'id_number' => $data['id_number'],
                    'bulk_dtr_id' =>  $record->id,
                    'dtr'=>json_encode($data['data']),
                    'status'=>"0",
                ]);

            })
            ->extraAttributes(['id' => 'dtr-id']);
    }

    public function dtrAction(): Action
    {
        return Action::make('dtr')
//            ->record(\App\Models\Leave\LeaveBulkDtr::query()->where('id', $this->bulk_dtr_id)->first())
            ->label('DTR')
            ->iconButton()
            ->icon('heroicon-m-printer')
            ->form(function ($arguments) {

                $keys = array_keys($arguments);
                $encrypted = Crypt::encryptString($keys[0]);
                $route = route('dtr_qrcode', ['dtr_id' =>$encrypted ]);

                $image = QrCode::generate($route);

                $base64Image = 'data:image/svg+xml;base64,' . base64_encode($image);

                return [
                    ViewField::make('dtr_print')
                        ->view('livewire.leave.asset.dtr_print')
                        ->viewData([
                            'data' => $arguments,
                            'qrcode' => $base64Image
                        ])
                ];
            })
            ->extraAttributes(['id' => 'dtr-id'])
            ->slideOver()
            ->modalSubmitAction(false);
    }
    public function render()
    {
        $data = \App\Models\Leave\LeaveBulkDtr::query()->where('id', $this->bulk_dtr_id)->first();
        return view('livewire.leave.bulk-dtr-view',compact('data'));
    }
}
