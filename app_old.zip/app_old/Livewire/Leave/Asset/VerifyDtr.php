<?php

namespace App\Livewire\Leave\Asset;

use Illuminate\Support\Facades\Crypt;
use Livewire\Component;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class VerifyDtr extends Component
{
    public $data = [];
    public string $qrcode,$date,$name= "";

    public function mount($dtr_id)
    {

        $query = $dtr_id;
        try {
            $decrypted = Crypt::decryptString($query);
        }catch (\Illuminate\Contracts\Encryption\DecryptException $e)
        {
            abort(404);
        }
        $check = \App\Models\Leave\LeaveMyDtr::query()->where("key",'=',$decrypted)->first();

        $arr = $check ? json_decode($check->dtr,true) : null;
        if (!!$arr)
        {
            $route = route('dtr_qrcode',['dtr_id'=>$query]);

            $image = QrCode::generate($route);

            $base64Image = 'data:image/svg+xml;base64,' . base64_encode($image);
            $this->qrcode = $base64Image;
            $this->date = $check->created_at;
            $this->data = $arr;
            $this->name = $check->key;

        }else{
            abort(404);
        }
    }
    public function render()
    {
        return view('livewire.leave.asset.verify-dtr');
    }
}
