<?php

namespace App\Livewire\Leave;

use Filament\Actions\ViewAction;
use Filament\Forms\Components\ViewField;
use Filament\Support\Colors\Color;
use Filament\Support\Enums\MaxWidth;
use Filament\Tables\Actions\Action;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;
use Livewire\Component;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class MyLeaveDtr extends Component implements HasForms, HasTable
{
    use InteractsWithTable;
    use InteractsWithForms;

    public $my_dtr, $new = [];

    public function mount()
    {


    }


    public function table(Table $table): Table
    {
        $user = Auth::user()->id_number;
        return $table
            ->query(\App\Models\Leave\LeaveMyDtr::query()->where("id_number", Auth::user()->id_number)->orderBy('id', 'desc'))
            ->columns([
                TextColumn::make('key'),
//                TextColumn::make('dtr'),

            ])
            ->actions([
                Action::make('View Dtr')
                    ->label('Print')
                    ->icon('heroicon-m-printer')
                    ->color(Color::Gray)
                    ->form(function ($record) {
                        $overlayImagePath = public_path('assets/r4a.png');

                        $encrypted = Crypt::encryptString($record->key);

                        $route = route('dtr_qrcode', ['dtr_id' => $encrypted]);


                        $image = QrCode::generate($route);

                        $base64Image = 'data:image/svg+xml;base64,' . base64_encode($image);
                        return [
                            ViewField::make('view')
                                ->view('livewire.leave.asset.my_dtr_view')
                                ->viewData([
                                    'qrcode' => $base64Image,
                                    'name' =>$record->key ,
                                ])
                        ];

                    })
                    ->slideOver()
                    ->modalSubmitAction(false)
                    ->modalCancelAction(false)
                    ->modalWidth(MaxWidth::FitContent),

            ]);
    }

    public function render()
    {
        return view('livewire.leave.my-leave-dtr');
    }
}
