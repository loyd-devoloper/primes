<?php

namespace App\Livewire\PersonalDataSheet;

use Livewire\Component;

class ViewPdfFile extends Component
{
    public function render()
    {
        return view('livewire.personal-data-sheet.view-pdf-file');
    }
}
