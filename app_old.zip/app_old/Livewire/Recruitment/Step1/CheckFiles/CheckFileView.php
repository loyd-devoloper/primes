<?php

namespace App\Livewire\Recruitment\Step1\CheckFile;

use Livewire\Component;

class CheckFileView extends Component
{
    public function render()
    {
        return view('livewire.recruitment.step1.check-file.check-file-view');
    }
}
