<?php

namespace App\Livewire\Recruitment\Step1\CheckFile;

use Livewire\Component;

class PdfViewer extends Component
{
    public function render()
    {
        return view('livewire.recruitment.step1.check-file.pdf-viewer');
    }
}
