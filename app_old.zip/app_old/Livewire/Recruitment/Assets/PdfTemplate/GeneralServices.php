<?php

namespace App\Livewire\Recruitment\Assets\PdfTemplate;

use Livewire\Component;

class GeneralServices extends Component
{
    public function render()
    {
        return view('livewire.recruitment.assets.pdf-template.general-services');
    }
}
