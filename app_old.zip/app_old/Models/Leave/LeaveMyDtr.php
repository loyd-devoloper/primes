<?php

namespace App\Models\Leave;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeaveMyDtr extends Model
{
    use HasFactory;

    protected $fillable = [
        'bulk_dtr_id',
        'id_number',
        'status',
        'type',
        'dtr',
        'attachment',
        'key',
    ];
}
