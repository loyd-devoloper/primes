<?php

namespace App\Providers;


use Illuminate\Support\ServiceProvider;


class FilamentServiceProvider extends ServiceProvider
{
    public function boot() {

    }

}
