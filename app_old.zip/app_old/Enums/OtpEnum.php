<?php

namespace App\Enums;

enum OtpEnum: string
{
    case VALIDATE = 'VALIDATE';
    case NOTVALIDATE = 'NOTVALIDATE';

}
